-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 10:12 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login account`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Id_No` varchar(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Phone_Number` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Id_No`, `First_Name`, `Last_Name`, `Phone_Number`, `Email`, `Password`) VALUES
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('675568', 'hfjjghifkmn', 'vddkiufjij', 'chfgutjitujj', 'fgu8778', 'iy6800'),
('675568', 'hfjjghifkmn', 'vddkiufjij', 'chfgutjitujj', 'fgu8778', 'iy6800'),
('rfggff', 'fdgfgh', 'fdgfnh', 'ghg', 'ghgj', 'hfghhj'),
('ergf', 'qhjytrfd', 'jhgfedsdf', 'weygfea', 'rthujyhtgf', 'ertuytrr'),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('SZDXCVBBNMN ', 'AWERTGHkk,mhnb', 'mhngvbg,kjm', ';ploioirdthg', 'poiuyte4u57yrh', ';poiuyfgj'),
('76ruy', 'hfhgf', 'hghff', 'jhhytf', 'hgr5rf', 'gh5rft'),
('wertyuyhgdf', 'jhgfsdfgn', 'AERTYUIOIUFH', 'dfghjmn', 'hjkjmhgbshjk', 'aghjhg'),
('lruokhgohiskl', 'a\'k;djfks;d,x.', 'alsdfk.lm;', 'asdfl;sm.,', 'p\';aks;ef\'sjok', '\\\'s;lkdijk;'),
('123323453456', 'fabnroni', 'uyordfojl087-', '0783490', 'ijhojhd@jigh.com', '2345ty4epro'),
('uygjhiulyhjbu', 'gvhbihjbjh', 'khliuhluihiu', '0890767yy89', '768iuu9po@bnk;l,.cpm', '78ugo87ty978o7'),
('12345', 'fab', 'brice', '078', 'fabbrice', '1234'),
('12345', '12345', '12345', '12345', '1024', '1024'),
('123', '123', '123', '123', '123', '1234'),
('890', '890', '890', '890', '900', '800'),
('890', '890', '890', '890', '900', '800'),
('9999', '9999', '9999', '9999', 'Fabrice', '222004158');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
